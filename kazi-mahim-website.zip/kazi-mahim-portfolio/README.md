# Kazi Mahim — Personal Portfolio

A dark, cinematic, futuristic + literary personal portfolio built with plain HTML, CSS and JavaScript.

## Run
Open `index.html` in a browser, or upload the whole folder to Replit / GitHub Pages.

## Included
- Glitch loading intro
- Heavy scroll reveal animations
- Custom cursor on desktop
- Responsive mobile layout
- Kazi Mahim profile image
- About, Interests and Contact sections
- Instagram and email links
